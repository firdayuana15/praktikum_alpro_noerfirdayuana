﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Praktikum_ALPRO.Migrations
{
    public partial class dbkainCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "bahan",
                columns: table => new
                {
                    id_bahan = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    jenis_bahan = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_kain = table.Column<int>(type: "int", nullable: false),
                    ukuran = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_bahan", x => x.id_bahan);
                });

            migrationBuilder.CreateTable(
                name: "kain",
                columns: table => new
                {
                    id_kain = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    warna_kain = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kain", x => x.id_kain);
                });

            migrationBuilder.CreateTable(
                name: "stok",
                columns: table => new
                {
                    id_stok = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Stok = table.Column<int>(type: "int", nullable: false),
                    harga_permeter = table.Column<double>(type: "float", nullable: false),
                    id_bahan = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_stok", x => x.id_stok);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "bahan");

            migrationBuilder.DropTable(
                name: "kain");

            migrationBuilder.DropTable(
                name: "stok");
        }
    }
}
