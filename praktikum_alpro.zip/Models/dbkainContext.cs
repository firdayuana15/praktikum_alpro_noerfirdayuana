using Microsoft.EntityFrameworkCore;

namespace praktikum_alpro.Models
{
    public class dbkain : DbContext
    {
        public dbkain(DbContextOptions<dbkain> options)
            : base(options)
        {
        }
        public DbSet<kain> kain { get; set; }
        public DbSet<bahan> bahan { get; set; }
        public DbSet<stok> stok { get; set; }
        
     
    }
}