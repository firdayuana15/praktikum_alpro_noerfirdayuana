using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace praktikum_alpro.Models
{
    public class bahan
    {
       [Key]
       [Column(TypeName ="varchar")]
       public string id_bahan { get; set; }

       [Column(TypeName ="varchar")]
       public string jenis_bahan { get; set; }

       [Column(TypeName ="varchar")]
       public string ukuran { get; set; }

       [ForeignKey("id_bahan")]
       public ICollection<stok> stoks { get; set;}
    }
}