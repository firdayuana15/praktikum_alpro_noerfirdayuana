using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace praktikum_alpro.Models
{
    public class stok
    {
       [Key]
       [Column(TypeName ="varchar")]
       public string id_stok { get; set; }

       [Column(TypeName ="varchar")]
       public string stok_kain { get; set; }

       [Column(TypeName ="varchar")]
       public string harga_permeter { get; set; }
    }
}