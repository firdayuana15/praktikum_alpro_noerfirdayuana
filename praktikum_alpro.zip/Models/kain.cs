using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace praktikum_alpro.Models
{
    public class kain
    {
       [Key]
       [Column(TypeName ="varchar")]
       public string id_kain { get; set; }

       [Column(TypeName ="varchar")]
       public string warna_kain { get; set; }

       [ForeignKey("id_kain")]
       public ICollection<bahan> bahans { get; set;}
    }
}